跟Unknwon学习Go编程基础, 这里是练习代码
