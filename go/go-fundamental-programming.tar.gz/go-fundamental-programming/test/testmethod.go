package main

import (
    "fmt"
)

type Myint int

func main() {
    var a Myint = 1
    a.Increase()
    fmt.Println(a)
}

func (a *Myint) Increase() {
    *a = 100
}
